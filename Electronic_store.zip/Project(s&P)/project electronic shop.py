import mysql.connector as mq
import sqlite3 as sql1
from datetime import date
today = date.today()


mysql = mq.connect(host = "localhost", username = "root", password = "Piyush@1234", database = "electronic_store")
if (mysql):
    print("Connection Establised")
else:
    print("Some Error")

cursor = mysql.cursor()
AdminId=9588280333
AdminPass="Suraj@333"
welcomemsg = "WELCOME TO SURAJ AND PIUYS'S ELECTRONIC STORE"
print(welcomemsg.center(50))
b=int(input("Please Chose Option :: \n\t 1.Admin \n\t 2.User \n\t ::"))
if b==1:
   while True:
    c=input("please enter the Id ::")
    d=input("please enter the Password ::")
    if c==AdminId or d==AdminPass:
        print("Welcome Suraj Jadhav".center(100))
        ac=int(input("Please Chose Action ::\n\t 1.See All Products \n\t 2.Add Product \n\t 3.Remove Product \n\t 4.Update Product Price \n\t :: "))


#___________________________________________________ See Product __________________________________________________________________________________________

#see Mobiles
        if ac==1:
            bc=int(input("Which Products You Want To See ::\n\t 1.Mobile \n\t 2.Laptop \n\t 3.Camera \n\t ::"))
            if bc==1:
                try:
                    connection = mq.connect(host='localhost',database='electronic_store',user='root',password='Piyush@1234')
                    sql_select_Query = "select * from Mobile"
                    cursor = connection.cursor()
                    cursor.execute(sql_select_Query)
                    # get all records
                    records = cursor.fetchall()
                    for row in records:
                        print("Product_Id = ", row[0], )
                        print("Brand_Name = ", row[1])
                        print("Model_name  = ", row[2])
                        print("Price =", row[3])
                        print("Specifications  = ", row[4], "\n")
                    

                except mysql.connector.Error as e:
                    print("Error reading data from MySQL table", e)
                finally:
                    if connection.is_connected():
                        connection.close()
                        cursor.close()
                        print("MySQL connection is closed")
                abc=int(input("Please Enter Option :: \n\t 1.Go to Main Menue \n\t ::"))
                if abc==1:
                    continue
                print("Close")
                break


#See Laptops
            elif bc==2:
                try:
                    connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                    sql_select_Query = "select * from Laptops"
                    cursor = connection.cursor()
                    cursor.execute(sql_select_Query)
                    # get all records
                    records = cursor.fetchall()
                    for row in records:
                        print("Product_Id = ", row[0], )
                        print("Brand_Name = ", row[1])
                        print("Model_Name  = ", row[2])
                        print("Price =", row[3])
                        print("Specifications  = ", row[4], "\n")
                    

                except mysql.connector.Error as e:
                    print("Error reading data from MySQL table", e)
                finally:
                    if connection.is_connected():
                        connection.close()
                        cursor.close()
                        print("MySQL connection is closed")
                abc=int(input("Please Enter Option :: \n\t 1.Go to Main Menue \n\t ::"))
                if abc==1:
                    continue
                print("Close")
                break

#See TV

            elif bc==3:
                try:
                    connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                    sql_select_Query = "select * from TV"
                    cursor = connection.cursor()
                    cursor.execute(sql_select_Query)
                    # get all records
                    records = cursor.fetchall()
                    for row in records:
                        print("Product_Id = ", row[0], )
                        print("Brand_Name = ", row[1])
                        print("Model_Name  = ", row[2])
                        print("Price =", row[3])
                        print("Specifications  = ", row[4], "\n")
                    

                except mysql.connector.Error as e:
                    print("Error reading data from MySQL table", e)
                finally:
                    if connection.is_connected():
                        connection.close()
                        cursor.close()
                        print("MySQL connection is closed")
                abc=int(input("Please Enter Option :: \n\t 1.Go to Main Menue \n\t ::"))
                if abc==1:
                    continue
                print("Close")
                break







#_________________________________________________________________ Add Product ____________________________________________________________________________

                
        elif ac==2:
            print("Please Add The Product")
            a1=int(input("Which Product You Want To Add ::\n\t 1.Mobile \n\t 2.Laptop \n\t 3.Camera \n\t ::"))

#Add Mobiles
            if a1==1:
                   product_id=input("Please Enter The Product Id ::")
                   brand_name=input("Please Enter The Brand Name ::")
                   model_name=input("Please Enter The Model Name ::")
                   price=int(input("Please Enter Price ::"))
                   specifications=input("Please Enter specifications ::")
                   


                   connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                   cursor = connection.cursor()
                   sql= "INSERT INTO Mobile (Product_Id,Brand_Name,Model_name,Price,Specifications) VALUES (%s,%s,%s,%s,%s)"
                   val=(product_id,brand_name,model_name,price,specifications)
                   cursor.execute(sql,val)
                   connection.commit()
            

                   print("Product Added Successfully.")

#Add Laptopes
            elif a1==2:
                   product_id=input("Please Enter The Product Id ::")
                   brand_name=input("Please Enter The Brand Name ::")
                   model_name=input("Please Enter The Model Name ::")
                   price=int(input("Please Enter Price ::"))
                   specifications=input("Please Enter specifications ::")
                   


                   connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                   cursor = connection.cursor()
                   sql= "INSERT INTO Laptops(Product_Id,Brand_Name,Model_Name,Price,Specifications) VALUES (%s,%s,%s,%s,%s)"
                   val=(product_id,brand_name,model_name,price,specifications)
                   cursor.execute(sql,val)
                   connection.commit()
            

                   print("Product Added Successfully.")


#Add TV
            elif a1==3:
                   product_id=input("Please Enter The Product Id ::")
                   brand_name=input("Please Enter The Brand Name ::")
                   model_name=input("Please Enter The Model Name ::")
                   price=int(input("Please Enter Price ::"))
                   specifications=input("Please Enter specifications ::")
                   


                   connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                   cursor = connection.cursor()
                   sql= "INSERT INTO TV(Product_Id,Brand_Name,Model_Name,Price,Specifications) VALUES (%s,%s,%s,%s,%s)"
                   val=(product_id,brand_name,model_name,price,specifications)
                   cursor.execute(sql,val)
                   connection.commit()
            

                   print("Product Added Successfully.")
         


#______________________________________________________________ Remove Mobile __________________________________________________________________________________
        
#Remove Mobile
                   
        elif ac==3:
            print("Please Remove The Product")
            a2=int(input("Which Product You Want To Remove ::\n\t 1.Mobile \n\t 2.Laptop \n\t 3.Camera \n\t ::"))
            if a2==1:
                   d=input("Please Enter The Product Id ::")
                   connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                   cursor = connection.cursor()
                   sql1=(f'DELETE FROM Mobile WHERE Product_Id={d}')
                   cursor.execute(sql1)
                   connection.commit()
                   print("Product Remove Successfully.")
#Remove Laptop
                   
            elif a2==2:
                   e=input("Please Enter The Product Id ::")
                   connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                   cursor = connection.cursor()
                   sql1=(f'DELETE FROM Laptops WHERE Product_Id={e}')
                   cursor.execute(sql1)
                   connection.commit()
                   print("Product Remove Successfully.")

#Remove TV
                   
            elif a2==3:
                   f=input("Please Enter The Product Id ::")
                   connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                   cursor = connection.cursor()
                   sql1=(f'DELETE FROM TV WHERE Product_Id={f}')
                   cursor.execute(sql1)
                   connection.commit()
                   print("Product Remove Successfully.")
 


#___________________________________________________________ Update Price ____________________________________________________________

                   
#Update Mobile Price
        elif ac==4:
            print("Please Update Product Price")
            a3=int(input("Which Product's Price you Want To Update ::\n\t 1.Mobile \n\t 2.Laptop \n\t 3.Camera \n\t ::"))
            if a3==1:
                   c=input("Please Enter The Product Id ::")
                   d=int(input("Please Enter The Price ::"))
                   connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                   cursor = connection.cursor()
                   sql2=(f'UPDATE Mobile SET Price={d} WHERE Product_Id={c}')
                   cursor.execute(sql2)
                   connection.commit()
                   print("Product's Price Update Successfully.")


#Update Laptop Price

            elif a3==2:
                   y=input("Please Enter The Product Id ::")
                   x=int(input("Please Enter The Price ::"))
                   connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                   cursor = connection.cursor()
                   sql2=(f'UPDATE Laptops SET Price={x} WHERE Product_Id={y}')
                   cursor.execute(sql2)
                   connection.commit()
                   print("Product's Price Update Successfully.")


#Update TV Price

            elif a3==3:
                   s=input("Please Enter The Product Id ::")
                   u=int(input("Please Enter The Price ::"))
                   connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                   cursor = connection.cursor()
                   sql2=(f'UPDATE TV SET Price={u} WHERE Product_Id={s}')
                   cursor.execute(sql2)
                   connection.commit()
                   print("Product's Price Update Successfully.")
                   
        else:
            print("Please Choose Right Option")
            continue


    else:   
        print("Please Enter Valid Id and Password")
        
#_______________________________________________________________ Admin Page End _______________________________________________________________











elif b==2:
    while True:
     a=int(input("Please Select Option :: \n\t 1.New User \n\t 2.Already Exists \n\t ::"))
     if a==1:
        nm=input("Please Enter The Name ::")
        Mobile_No=int(input("Please Enter The Mob Number ::"))
        pss=input("Please Enter The Password ::")
        connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

        cursor = connection.cursor()
        sql= "INSERT INTO customers_deatils (Customer_Name,Mobile_No,Pass ) VALUES (%s,%s,%s)"
        val=(nm,Mobile_No,pss)
        cursor.execute(sql,val)
        connection.commit()
        print("Register Succesfully")
#_______________________________________________________________ User Login ________________________________________________________________________________
    
     elif a==2:
          connection = mq.connect(host='localhost',database='electronic_store',user='root',password='Piyush@1234')
          cursor = connection.cursor()        
          Mobile_No=int(input("Please Enter The Mob Number ::"))
          password=input("please enter the password ::")
          statement= f"SELECT Mobile_No FROM customers_deatils WHERE Mobile_No='{Mobile_No}' AND Pass= '{password}';"
          cursor.execute(statement)
          if cursor.fetchone():
                  print("Log in Successfully")
          else:
             print("User Not Exists Please register first")
             continue
     ac=int(input("Which Products You Want To Buy ::\n\t 1.Mobile \n\t 2.Laptop \n\t 3.Camera \n\t ::"))
     if 00==00:
            #bc=int(input("Which Products You Want To Buy ::\n\t 1.Mobile \n\t 2.Laptop \n\t 3.Camera \n\t ::"))
            if ac==1:
                try:
                    connection = mq.connect(host='localhost',database='electronic_store',user='root',password='Piyush@1234')
                    sql_select_Query = "select * from Mobile"
                    cursor = connection.cursor()
                    cursor.execute(sql_select_Query)
                    # get all records
                    records = cursor.fetchall()
                    for row in records:
                        print("Product_Id = ", row[0], )
                        print("Brand_Name = ", row[1])
                        print("Model_name  = ", row[2])
                        print("Price =", row[3])
                        print("Specifications  = ", row[4], "\n")
                    

                except mysql.connector.Error as e:
                    print("Error reading data from MySQL table", e)
                finally:
                    if connection.is_connected():
                        connection.close()
                        cursor.close()
                        print("MySQL connection is closed")
                pcode=input("Which Mobile You Want To Buy Please Enter Product Id ::" )

                connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                cursor = connection.cursor()
                sql= "INSERT INTO Orders (Mobile_No,Product_Id) VALUES (%s,%s)"
                val=(Mobile_No,pcode)
                cursor.execute(sql,val)
                connection.commit()  
                print('Order Placed Succesfully')
                abc=int(input("Please Enter Option :: \n\t 1.Shopping Continue  \n\t 2.Get Bill \n\t ::"))
                if abc==1:
                    print(f'Thanks for Order')
                    continue
                else:
                    break



            elif ac==2:
                try:
                    connection = mq.connect(host='localhost',database='electronic_store',user='root',password='Piyush@1234')
                    sql_select_Query = "select * from Laptops"
                    cursor = connection.cursor()
                    cursor.execute(sql_select_Query)
                    # get all records
                    records = cursor.fetchall()
                    for row in records:
                        print("Product_Id = ", row[0], )
                        print("Brand_Name = ", row[1])
                        print("Model_name  = ", row[2])
                        print("Price =", row[3])
                        print("Specifications  = ", row[4], "\n")
                    

                except mysql.connector.Error as e:
                    print("Error reading data from MySQL table", e)
                finally:
                    if connection.is_connected():
                        connection.close()
                        cursor.close()
                        print("MySQL connection is closed")
                pcode=input("Which Laptop You Want To Buy Please Enter Product Id ::" )

                connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                cursor = connection.cursor()
                sql= "INSERT INTO Orders (Mobile_No,Product_Id) VALUES (%s,%s)"
                val=(Mobile_No,pcode)
                cursor.execute(sql,val)
                connection.commit()  
                print('Order Placed Succesfully')
                abc=int(input("Please Enter Option :: \n\t 1.Shopping Continue  \n\t 2.Get Bill \n\t ::"))
                if abc==1:
                    print(f'Thanks for Order')
                    continue
                else:
                    break

            elif ac==3:
                try:
                    connection = mq.connect(host='localhost',database='electronic_store',user='root',password='Piyush@1234')
                    sql_select_Query = "select * from TV"
                    cursor = connection.cursor()
                    cursor.execute(sql_select_Query)
                    # get all records
                    records = cursor.fetchall()
                    for row in records:
                        print("Product_Id = ", row[0], )
                        print("Brand_Name = ", row[1])
                        print("Model_name  = ", row[2])
                        print("Price =", row[3])
                        print("Specifications  = ", row[4], "\n")
                    

                except mysql.connector.Error as e:
                    print("Error reading data from MySQL table", e)
                finally:
                    if connection.is_connected():
                        connection.close()
                        cursor.close()
                        print("MySQL connection is closed")
                pcode=input("Which Camera You Want To Buy Please Enter Product Id ::" )

                connection = mq.connect(host='localhost',
                                         database='electronic_store',
                                         user='root',
                                         password='Piyush@1234')

                cursor = connection.cursor()
                sql= "INSERT INTO Orders (Mobile_No,Product_Id) VALUES (%s,%s)"
                val=(Mobile_No,pcode)
                cursor.execute(sql,val)
                connection.commit()  
                print('Order Placed Succesfully')
                abc=int(input("Please Enter Option :: \n\t 1.Shopping Continue  \n\t 2.Get Bill \n\t ::"))
                if abc==1:
                    print(f'Thanks for Order')
                    continue
                else:
                    break
print(" ")
print("------------------------------------------------------------------------------------------------------------------------------")
print("SURAJ AND PIYUSH'S ELECTONIC SHOP".center(100))
print("Address : Sanpada Navi Mumbai".center(100))
print("Contact No : 9588280333,9672377459".center(200))
print("------------------------------------------------------------------------------------------------------------------------------")
connection = mq.connect(host='localhost',database='electronic_store',user='root',password='Piyush@1234')
sql_select_Query =f'SELECT Customer_Name FROM customers_deatils WHERE Mobile_No = { Mobile_No }'
cursor = connection.cursor()
cursor.execute(sql_select_Query)
records = cursor.fetchall()
for row in records:
    print(f"Customer Name ={row[0]}",f"Date :{today}".center(140))
    print("")
                   
    #for All product_Id deatils

    #mobile  
    mobilepid=[]
    mpid='SELECT  Product_Id FROM Mobile'
    cursor.execute(mpid)
    recordsmp = cursor.fetchall()
    for x in recordsmp:
     if x not in mobilepid:
      mobilepid.append(x)
        #print(mobilepid)

    #laptop
    laptoppid=[]
    lpid='SELECT  Product_Id FROM Laptops'
    cursor.execute(lpid)
    recordsmp = cursor.fetchall()
    for x in recordsmp:
         if x not in laptoppid:
          laptoppid.append(x)
        #print(laptoppid)


    #TV
    camerapid=[]
    cpid='SELECT  Product_Id FROM TV'
    cursor.execute(cpid)
    recordsmp = cursor.fetchall()
    for x in recordsmp:
        if x not in camerapid:
         camerapid.append(x)
        #print(camerapid)

    #Buy products by coustmer
z=[]
buyproduct=f'SELECT Product_Id FROM Orders WHERE Mobile_No = { Mobile_No }'
cursor.execute(buyproduct)
records2 = cursor.fetchall()
for x in records2:
      if x not in z:
        z.append(x)

count=0
for x in z:
    pd=x
    if pd in mobilepid:
        connection = mq.connect(host='localhost',database='electronic_store',user='root',password='Piyush@1234')
        buyproductd='SELECT Brand_Name,Model_name,Price FROM Mobile WHERE Product_Id IN (%s)'    
        value=(pd)
        cursor = connection.cursor()
        cursor.execute(buyproductd,value)
        recordss = cursor.fetchall()
        for i in recordss:
            count+=1
        for row in recordss:
           print(count," ",row[0],"        ",row[1],"                          ",row[2],"Rs" )
      
    elif pd in laptoppid:
        connection = mq.connect(host='localhost',database='electronic_store',user='root',password='Piyush@1234')
        buyproductd='SELECT Brand_Name,Model_name,Price FROM Laptops WHERE Product_Id IN (%s)'    
        value=(pd)
        cursor = connection.cursor()
        cursor.execute(buyproductd,value)
        recordss = cursor.fetchall()
        for i in recordss:
            count+=1
        for row in recordss:
            print(count," ",row[0],"        ",row[1],"                         ",row[2],"Rs" )
    elif pd in camerapid:
        connection = mq.connect(host='localhost',database='electronic_store',user='root',password='Piyush@1234')
        buyproductd='SELECT Brand_Name,Model_name,Price FROM TV WHERE Product_Id IN (%s)'    
        value=(pd)
        cursor = connection.cursor()
        cursor.execute(buyproductd,value)
        recordss = cursor.fetchall()
        for i in recordss:
            count+=1
        for row in recordss:
             print(count," ",row[0],"        ",row[1],"                         ",row[2],"Rs" )  
    else:
        continue



#total Bill
tbb=()
for x in z:
    pd=x
    
    if pd in mobilepid:
            connection = mq.connect(host='localhost',database='electronic_store',user='root',password='Piyush@1234')
            buyproductd='SELECT Price FROM Mobile WHERE Product_Id IN (%s)'    
            value=(pd)
            cursor = connection.cursor()
            cursor.execute(buyproductd,value)
            recordss = cursor.fetchall()
            for row in recordss:
              tbb+=row
             
      
    elif pd in laptoppid:
            connection = mq.connect(host='localhost',database='electronic_store',user='root',password='Piyush@1234')
            buyproductd='SELECT Price FROM Laptops WHERE Product_Id IN (%s)'    
            value=(pd)
            cursor = connection.cursor()
            cursor.execute(buyproductd,value)
            recordss = cursor.fetchall()
            for row in recordss:
              tbb+=row
    elif pd in camerapid:
            connection = mq.connect(host='localhost',database='electronic_store',user='root',password='Piyush@1234')
            buyproductd='SELECT Price FROM TV WHERE Product_Id IN (%s)'    
            value=(pd)
            cursor = connection.cursor()
            cursor.execute(buyproductd,value)
            recordss = cursor.fetchall()
            for row in recordss:
              tbb+=row
    else:
        break


tbbb=0    
for x in tbb:
    bb=x
    res=int(bb)
    tbbb+=res

print(" ")
print("-------------------------------------------------------------------------------------------------------------------------------")    
print(f"Total -{tbbb} Rs".center(130))
print("-------------------------------------------------------------------------------------------------------------------------------")
print(" ")
print("  _/\_ Thank You, Visit Again _/\_".center(80))
print(" ")
print("-------------------------------------------------------------------------------------------------------------------------------")



































